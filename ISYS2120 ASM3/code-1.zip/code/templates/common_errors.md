programming error - maybe an empty input resulting in a type error
database error - not all inputs provided
