# ISYS2120 2xs2 Assignment - Opal train data

This assignment contains some generated and some actual information that has to do with Sydney Trains, Metro, Light Rail and the opal
card that is used to travel on these services.

## To start
1. Update config.ini
2. change the connectiontarget in database.py line 90
3. install modules if needed by using:
    ```pip install -r requirements.txt
    ```
