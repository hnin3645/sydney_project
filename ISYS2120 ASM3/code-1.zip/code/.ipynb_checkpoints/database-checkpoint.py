#!/usr/bin/env python3
# Imports
from modules import pg8000
import configparser
import sys
from datetime import datetime
#  Common Functions
##     database_connect()
##     dictfetchall(cursor,sqltext,params)
##     dictfetchone(cursor,sqltext,params)
##     print_sql_string(inputstring, params)


################################################################################
# Connect to the database
#   - This function reads the config file and tries to connect
#   - This is the main "connection" function used to set up our connection
################################################################################

def database_connect():
    # Read the config file
    config = configparser.ConfigParser()
    config.read('config.ini')

    # Create a connection to the database
    connection = None

    # choose a connection target, you can use the default or
    # use a different set of credentials that are setup for localhost or winhost
    connectiontarget = 'DATABASE'
    # connectiontarget = 'DATABASELOCAL'
    try:
        '''
        This is doing a couple of things in the back
        what it is doing is:

        connect(database='y2?i2120_unikey',
            host='soit-db-pro-2.ucc.usyd.edu.au,
            password='password_from_config',
            user='y2?i2120_unikey')
        '''
        targetdb = ""
        if ('database' in config[connectiontarget]):
            targetdb = config[connectiontarget]['database']
        else:
            targetdb = config[connectiontarget]['user']

        connection = pg8000.connect(database=targetdb,
                                    user=config[connectiontarget]['user'],
                                    password=config[connectiontarget]['password'],
                                    host=config[connectiontarget]['host'],
                                    port=int(config[connectiontarget]['port']))
        print('Connected successfully.')
    except pg8000.OperationalError as e:
        print("""Error, you haven't updated your config.ini or you have a bad
        connection, please try again. (Update your files first, then check
        internet connection)
        """)
        print(e)
    except pg8000.ProgrammingError as e:
        print("""Error, config file incurrect: check your password and username""")
        print(e)
    except Exception as e:
        print(e)

    # Return the connection to use
    return connection

######################################
# Database Helper Functions
######################################
def dictfetchall(cursor,sqltext,params=None):
    """ Returns query results as list of dictionaries."""
    """ Useful for read queries that return 1 or more rows"""

    result = []
    
    cursor.execute(sqltext,params)
    if cursor.description is not None:
        cols = [a[0].decode("utf-8") for a in cursor.description]
        
        returnres = cursor.fetchall()
        if returnres is not None or len(returnres > 0):
            for row in returnres:
                result.append({a:b for a,b in zip(cols, row)})

        # cursor.close()
    print("returning result: ",result)
    return result

def dictfetchone(cursor,sqltext,params=None):
    """ Returns query results as list of dictionaries."""
    """ Useful for create, update and delete queries that only need to return one row"""

    # cursor = conn.cursor()
    result = []
    cursor.execute(sqltext,params)
    if (cursor.description is not None):
        print("cursor description", cursor.description)
        cols = [a[0].decode("utf-8") for a in cursor.description]
        returnres = cursor.fetchone()
        print("returnres: ", returnres)
        if (returnres is not None):
            result.append({a:b for a,b in zip(cols, returnres)})
    return result

##################################################
# Print a SQL string to see how it would insert  #
##################################################

def print_sql_string(inputstring, params=None):
    """
    Prints out a string as a SQL string parameterized assuming all strings
    """
    if params is not None:
        if params != []:
           inputstring = inputstring.replace("%s","'%s'")
    
    print(inputstring % params)

###############
# Login       #
###############

def check_login(username, password):
    '''
    Check Login given a username and password
    '''
    # Ask for the database connection, and get the cursor set up
    conn = database_connect()
    print("checking login")
    if(conn is None):
        return None
    cur = conn.cursor()
    try:
        # Try executing the SQL and get from the database
        
        sql = """SELECT *
                FROM opaltravel.Users
                    JOIN opaltravel.UserRoles ON
                        (opaltravel.Users.userroleid = opaltravel.UserRoles.userroleid)
                WHERE userid=%s AND password=%s"""
        print_sql_string(sql, (username, password))
        r = dictfetchone(cur, sql, (username, password)) # Fetch the first row
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        return r
    except:
        # If there were any errors, return a NULL row printing an error to the debug
        print("Error Invalid Login")
    cur.close()                     # Close the cursor
    conn.close()                    # Close the connection to the db
    return None
    
########################
#List All Items#
########################

# Get all the rows of users and return them as a dict
def list_users():
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    returndict = None

    try:
        # Set-up our SQL query
        sql = """SELECT *
                    FROM opaltravel.users """
        
        # Retrieve all the information we need from the query
        returndict = dictfetchall(cur,sql)

        # report to the console what we recieved
        print(returndict)
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return returndict
    

def list_userroles():
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    returndict = None

    try:
        # Set-up our SQL query
        sql = """SELECT *
                    FROM opaltravel.userroles """
        
        # Retrieve all the information we need from the query
        returndict = dictfetchall(cur,sql)

        # report to the console what we recieved
        print(returndict)
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return returndict
    

########################
#List Single Items#
########################

# Get all rows in users where a particular attribute matches a value
def list_users_equifilter(attributename, filterval):
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    val = None

    try:
        # Retrieve all the information we need from the query
        sql = f"""SELECT *
                    FROM opaltravel.users
                    WHERE {attributename} = %s """
        val = dictfetchall(cur,sql,(filterval,))
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database: ", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return val
    


########################### 
#List Report Items #
###########################
    
# # A report with the details of Users, Userroles
def list_consolidated_users():
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    returndict = None

    try:
        # Set-up our SQL query
        sql = """SELECT *
                FROM opaltravel.users 
                    JOIN opaltravel.userroles 
                    ON (opaltravel.users.userroleid = opaltravel.userroles.userroleid) ;"""
        
        # Retrieve all the information we need from the query
        returndict = dictfetchall(cur,sql)

        # report to the console what we recieved
        print(returndict)
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return returndict

def list_user_stats():
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    returndict = None

    try:
        # Set-up our SQL query
        sql = """SELECT userroleid, COUNT(*) as count
                FROM opaltravel.users 
                    GROUP BY userroleid
                    ORDER BY userroleid ASC ;"""
        
        # Retrieve all the information we need from the query
        returndict = dictfetchall(cur,sql)

        # report to the console what we recieved
        print(returndict)
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return returndict
    

####################################
##  Search Items - inexact matches #
####################################

# Search for users with a custom filter
# filtertype can be: '=', '<', '>', '<>', '~', 'LIKE'
def search_users_customfilter(attributename, filtertype, filterval):
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    val = None

    # arrange like filter
    filtervalprefix = ""
    filtervalsuffix = ""
    if str.lower(filtertype) == "like":
        filtervalprefix = "'%"
        filtervalsuffix = "%'"
        
    try:
        # Retrieve all the information we need from the query
        sql = f"""SELECT *
                    FROM opaltravel.users
                    WHERE lower({attributename}) {filtertype} {filtervalprefix}lower(%s){filtervalsuffix} """
        print_sql_string(sql, (filterval,))
        val = dictfetchall(cur,sql,(filterval,))
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database: ", sys.exc_info()[0])

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return val


#####################################
##  Update Single Items by PK       #
#####################################


# Update a single user
def update_single_user(userid, firstname, lastname,userroleid,password):
    # Get the database connection and set up the cursor
    conn = database_connect()
    if(conn is None):
        # If a connection cannot be established, send an Null object
        return None
    # Set up the rows as a dictionary
    cur = conn.cursor()
    val = None

    # Data validation checks are assumed to have been done in route processing

    try:
        setitems = ""
        attcounter = 0
        if firstname is not None:
            setitems += "firstname = %s\n"
            attcounter += 1
        if lastname is not None:
            if attcounter != 0:
                setitems += ","
            setitems += "lastname = %s\n"
            attcounter += 1
        if userroleid is not None:
            if attcounter != 0:
                setitems += ","
            setitems += "userroleid = %s::bigint\n"
            attcounter += 1
        if password is not None:
            if attcounter != 0:
                setitems += ","
            setitems += "password = %s\n"
            attcounter += 1
        # Retrieve all the information we need from the query
        sql = f"""UPDATE opaltravel.users
                    SET {setitems}
                    WHERE userid = {userid};"""
        print_sql_string(sql,(firstname, lastname,userroleid,password))
        val = dictfetchone(cur,sql,(firstname, lastname,userroleid,password))
        conn.commit()
        
    except:
        # If there are any errors, we print something nice and return a null value
        print("Error Fetching from Database: ", sys.exc_info()[0])
        print(sys.exc_info())

    # Close our connections to prevent saturation
    cur.close()
    conn.close()

    # return our struct
    return val


##  Insert / Add

def add_user_insert(firstname, lastname,userroleid,password):
    """
    Add a new User to the system
    """
    # Data validation checks are assumed to have been done in route processing

    conn = database_connect()
    if(conn is None):
        return None
    cur = conn.cursor()
    sql = """
        INSERT into opaltravel.Users(firstname, lastname, userroleid, password)
        VALUES (%s,%s,%s,%s);
        """
    print_sql_string(sql, (firstname, lastname,userroleid,password))
    try:
        # Try executing the SQL and get from the database
        sql = """
        INSERT into opaltravel.Users(firstname, lastname, userroleid, password)
        VALUES (%s,%s,%s,%s);
        """

        cur.execute(sql,(firstname, lastname,userroleid,password))
        
        # r = cur.fetchone()
        r=[]
        conn.commit()                   # Commit the transaction
        print("return val is:")
        print(r)
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        return r
    except:
        # If there were any errors, return a NULL row printing an error to the debug
        print("Unexpected error adding a user:", sys.exc_info()[0])
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        raise

##  Delete
###     delete_user(userid)
def delete_user(userid):
    """
    Remove a user from your system
    """
    # Data validation checks are assumed to have been done in route processing
    conn = database_connect()
    if(conn is None):
        return None
    cur = conn.cursor()
    try:
        # Try executing the SQL and get from the database
        sql = f"""
        DELETE
        FROM opaltravel.users
        WHERE userid = {userid};
        """

        cur.execute(sql,())
        conn.commit()                   # Commit the transaction
        r = []
        # r = cur.fetchone()
        # print("return val is:")
        # print(r)
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        return r
    except:
        # If there were any errors, return a NULL row printing an error to the debug
        print("Unexpected error deleting  user with id ",userid, sys.exc_info()[0])
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        raise

def show_all_trips():
    conn = database_connect()
    if conn is None:
        return None  # Returns None if the connection could not be established
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")
    try:
        trips_list = dictfetchall(cur, "SELECT * FROM trips ORDER BY tripid")
        cur.close()  # close cursor
        conn.close()
        return trips_list
    except Exception as e:
        # If there are any errors, return None and print the error message.
        print(f"Unexpected error retrieving trips: {e}")
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        raise

def filter_trips_by_date(date):
    conn = database_connect()
    if conn is None:
        return None  # If the connection cannot be established, return None
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")
    try:
        trips_list = dictfetchall(cur, "SELECT * FROM trips WHERE traveldate = %s ORDER BY tripid", (date,))
        cur.close()  # Close the cursor
        conn.close()  # Close the connection to the db
        return trips_list
    except Exception as e:
        # If any error occurs, return None and print the error message
        print(f"Unexpected error retrieving trips: {e}")
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        raise

def get_trip(trip_id):
    conn = database_connect()
    if conn is None:
        return None  # If the connection cannot be established, return None
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")
    try:
        trips_list = dictfetchall(cur, "SELECT * FROM trips WHERE tripid = %s", (trip_id,))
        cur.close()  # Close the cursor
        conn.close()  # Close the connection to the db
        return trips_list
    except Exception as e:
        # If any error occurs, return None and print the error message
        print(f"Unexpected error retrieving trips: {e}")
        cur.close()                     # Close the cursor
        conn.close()                    # Close the connection to the db
        raise
        
def add_trip(trip_data):
    conn = database_connect()
    if conn is None:
        return {'success': False, 'errors': ['Unable to establish database connection']}
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")

    try:
        sql = """
        INSERT INTO trips(cardid, traveldate, entrystationid, exitstationid, tripstarttime) 
        VALUES (%s, %s, %s, %s, %s)
        """
        cur.execute(sql, (trip_data['cardid'], trip_data['traveldate'], trip_data['entrystationid'], trip_data['exitstationid'], trip_data['tripstarttime']))
        conn.commit()
        return {'success': True}
    except Exception as e:
        conn.rollback()
        print(f"Unexpected error adding trip: {e}")
        return {'success': False, 'errors': [str(e)]}
    finally:
        cur.close()
        conn.close()  # Close connection
        
def update_trip(trip_id, trip_data):
    conn = database_connect()
    if conn is None:
        return {'success': False, 'errors': ['Unable to establish database connection']}
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")

    try:
        sql = """
        UPDATE trips
        SET cardid=%s, traveldate=%s, entrystationid=%s, exitstationid=%s, tripstarttime=%s
        WHERE tripid=%s
        """
        cur.execute(sql, (trip_data['cardid'], trip_data['traveldate'], trip_data['entrystationid'], trip_data['exitstationid'], trip_data['tripstarttime'], trip_id))
        
        if cur.rowcount == 0:
            conn.rollback()
            return {'success': False, 'errors': ['No corresponding trip ID was found.']}
        
        conn.commit()
        return {'success': True}
    except Exception as e:
        conn.rollback()
        print(f"Unexpected error updating trip: {e}")
        return {'success': False, 'errors': [str(e)]}
    finally:
        cur.close()
        conn.close()



def delete_trip(trip_id):
    conn = database_connect()
    if conn is None:
        return {'success': False, 'errors': ['Unable to establish database connection']}
    
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")

    try:
        sql = """DELETE FROM trips WHERE tripid=%s"""
        cur.execute(sql, (trip_id,))
        if cur.rowcount == 0:
            conn.rollback()  # Rollback if no rows were deleted, implying trip_id was not found
            return {'success': False, 'errors': ['The corresponding trip ID was not found and the delete operation was not executed.']}
        
        conn.commit()  # Commit the changes if the row was deleted
        return {'success': True}
    except Exception as e:
        conn.rollback()
        print(f"Unexpected error deleting trip: {e}")
        return {'success': False, 'errors': [str(e)]}
    finally:
        cur.close()
        conn.close()

def generate_report():
    conn = database_connect()
    if conn is None:
        return {'success': False, 'errors': ['Unable to establish database connection']}
    
    cur = conn.cursor()
    try:
        cur.execute("SET search_path TO opaltravel;")
        
        sql = "SELECT entrystationid, COUNT(*) as trip_count FROM trips GROUP BY entrystationid"
        cur.execute(sql)
        rows = cur.fetchall()
        
        # Convert rows to a list of dictionaries to make them easier to work with
        columns = [column[0].decode('utf-8') if isinstance(column[0], bytes) else column[0] for column in cur.description]
        report = [dict(zip(columns, row)) for row in rows]
        
        # Decode byte strings to normal strings
        for record in report:
            for key, value in record.items():
                if isinstance(value, bytes):
                    record[key] = value.decode('utf-8')
        
        return {'success': True, 'data': report}
    except Exception as e:
        print(f"Unexpected error generating report: {e}")
        return {'success': False, 'errors': [str(e)]}
    finally:
        cur.close()
        conn.close()



def check_trip_data(trip_data):
    conn = database_connect()
    if conn is None:
        return {'success': False, 'errors': ['Unable to establish database connection']}
    cur = conn.cursor()
    cur.execute("SET search_path TO opaltravel;")
    
    errors = []

    # Converting a traveldate to a date object in string format
    try:
        travel_date = datetime.strptime(trip_data['traveldate'], '%Y-%m-%d').date()
    except ValueError:
        errors.append("Travel date format is invalid. Use YYYY-MM-DD.")

    # Check if cardid exists in OpalCards
    card_check_sql = "SELECT cardid FROM OpalCards WHERE cardid = %s"
    card_exists = dictfetchone(cur, card_check_sql, (trip_data['cardid'],))
    if not card_exists:
        errors.append("Card ID does not exist in OpalCards.")

    # Check if traveldate is today or before
    if travel_date > datetime.now().date():
        errors.append("Travel date cannot be in the future.")

    # Check if entrystationid exists in Stations
    entry_station_check_sql = "SELECT stationid FROM Stations WHERE stationid = %s"
    entry_station_exists = dictfetchone(cur, entry_station_check_sql, (trip_data['entrystationid'],))
    if not entry_station_exists:
        errors.append("Entry Station ID does not exist in Stations.")

    # Check if the exitstationid exists in Stations
    exit_station_check_sql = "SELECT stationid FROM Stations WHERE stationid = %s"
    exit_station_exists = dictfetchone(cur, exit_station_check_sql, (trip_data['exitstationid'],))
    if not exit_station_exists:
        errors.append("Exit Station ID does not exist in Stations.")
    
    # Validation Time Format
    try:
        # This will throw a ValueError if the time is not in HH:MM:SS format or if the time value is incorrect.
        datetime.strptime(trip_data['tripstarttime'], '%H:%M:%S').time()
    except ValueError as e:
        errors.append(f"Trip start time format is invalid: {e}")
        
    # Check for errors before attempting a query
    if errors:
        return errors  # If there is an error, return the error list directly

    # Check for duplicate travel entries
    trip_check_sql = """SELECT tripid FROM Trips WHERE cardid=%s AND traveldate=%s AND 
                        entrystationid=%s AND exitstationid=%s AND tripstarttime=%s"""
    trip_exists = dictfetchone(cur, trip_check_sql, (trip_data['cardid'], travel_date,
                                           trip_data['entrystationid'], trip_data['exitstationid'],
                                           trip_data['tripstarttime']))
    if trip_exists:
        errors.append("An identical trip already exists.")

    return errors

# filtered_date = '2023-02-19'
# new_trip_data = {
#     'cardid': 5,
#     'traveldate': '2023-02-19',
#     'entrystationid': 1,
#     'exitstationid': 4,
#     'tripstarttime': '11:00:00'
# }
# updated_data = {
#     'cardid': 6,
#     'traveldate': '2023-02-19',
#     'entrystationid': 1,
#     'exitstationid': 4,
#     'tripstarttime': '11:00:00'
# }
# trip_id_to_update = 2
# trip_id_to_delete = 1

# if __name__ == "__main__":
#     get_trip(2)
#     filter_trips_by_date(filtered_date)
#     connection = database_connect()
#     conn = connection.cursor()
#     conn.execute("SET search_path TO opaltravel;")

    # show_all_trips()

    

    # add_trip(new_trip_data)
    # filter_trips_by_date(filtered_date)

    # update_trip(trip_id_to_update, updated_data)
    

    # delete_trip(trip_id_to_delete)
    # filter_trips_by_date(filtered_date)
    # show_all_trips()

    # report = generate_report()
    # if report['success']:
    #     print("Report generated successfully.")
    #     for data in report['data']:
    #         print(data)
    # else:
    #     print("Failed to generate report.")
    #     print("Errors:", report['errors'])
    
#     connection.close()